using ConstructionCompany;

var objects = new List<ConstructionObject>
{
    new ResidentialBuilding("Жилой комплекс «Северный»", "ул. Строителей, 10", 5200, 95000, "фундамент"),
    new CommercialBuilding("Бизнес-центр «Гранит»", "пр. Мира, 25", 3600, 120000, "стены"),
    new Road("Трасса Р-1", "Калужское направление, км 40", 8500, 18500, "подготовка площадки"),
    new Bridge("Мост через речку Каменка", "р. Каменка, участок 12", 420, 285000, "фундамент"),
    new IndustrialBuilding("Завод «Прогресс»", "промзона Север, корпус 3", 7800, 78000, "завершение")
};

var employees = new List<Employee>
{
    new Builder("Иван Петров", 32, 65000),
    new Builder("Сергей Соколов", 28, 62000),
    new Engineer("Анна Иванова", 35, 95000),
    new Foreman("Михаил Орлов", 41, 82000)
};

var projects = new List<ConstructionProject>
{
    new("Комплексная застройка микрорайона", new DateTime(2026, 3, 1), new DateTime(2027, 11, 30), "Елена Смирнова"),
    new("Развитие дорожной сети", new DateTime(2026, 5, 15), new DateTime(2028, 8, 20), "Дмитрий Козлов")
};

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.UseDefaultFiles();
app.UseStaticFiles();

app.MapGet("/api/objects", () => objects.Select(item => new
{
    item.Name,
    item.Address,
    item.Cost,
    item.ConstructionStage,
    Type = item.GetType().Name,
    Description = item.GetDescription()
}));

app.MapGet("/api/projects", () => projects);

app.MapGet("/api/employees", () => employees.Select(employee => new
{
    employee.FullName,
    employee.Age,
    employee.Salary,
    Position = employee.GetType().Name
}));

app.MapGet("/api/costs", () => new
{
    Items = objects.Select(item => new { item.Name, Cost = item.CalculateCost() }),
    Total = objects.Sum(item => item.CalculateCost())
});

app.MapGet("/api/work", () => new
{
    Objects = objects.Select(item => new { item.Name, Description = item.GetDescription() }),
    Employees = employees.Select(employee => new
    {
        employee.FullName,
        Position = employee.GetType().Name
    })
});

app.Run();
