@echo off
cd /d "%~dp0"
dotnet build .\ConstructionCompany.csproj -o .\web-build
if errorlevel 1 (
  echo Не удалось собрать сайт. Проверьте установку .NET SDK 8.
  pause
  exit /b 1
)
echo Сайт запущен: http://localhost:5080
dotnet .\web-build\ConstructionCompany.dll --urls http://localhost:5080
