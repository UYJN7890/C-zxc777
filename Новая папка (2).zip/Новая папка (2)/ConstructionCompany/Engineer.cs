namespace ConstructionCompany;

public class Engineer : Employee
{
    public Engineer(string fullName, int age, double salary) : base(fullName, age, salary) { }

    public override void Work()
    {
        Console.WriteLine($"{FullName} выполняет проектирование, расчёты и проверку качества конструкций.");
    }
}
