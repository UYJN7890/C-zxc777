namespace ConstructionCompany;

public class CommercialBuilding : ConstructionObject
{
    public double Area { get; set; }
    public double PricePerSquareMeter { get; set; }

    public CommercialBuilding(string name, string address, double area, double pricePerSquareMeter, string stage)
        : base(name, address, 0, stage)
    {
        Area = area;
        PricePerSquareMeter = pricePerSquareMeter;
        Cost = CalculateCost();
    }

    public override void Build()
    {
        Console.WriteLine($"Строится коммерческое здание «{Name}»: установка инженерных систем и торговых помещений.");
    }

    public override double CalculateCost()
    {
        return Area * PricePerSquareMeter;
    }

    public override string GetDescription()
    {
        return $"Коммерческое здание площадью {Area:N2} м².";
    }
}
