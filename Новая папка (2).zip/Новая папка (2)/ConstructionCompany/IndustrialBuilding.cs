namespace ConstructionCompany;

public class IndustrialBuilding : ConstructionObject
{
    public double Area { get; set; }
    public double PricePerSquareMeter { get; set; }

    public IndustrialBuilding(string name, string address, double area, double pricePerSquareMeter, string stage)
        : base(name, address, 0, stage)
    {
        Area = area;
        PricePerSquareMeter = pricePerSquareMeter;
        Cost = CalculateCost();
    }

    public override void Build()
    {
        Console.WriteLine($"Строится промышленный объект «{Name}»: монтаж каркаса и технологического оборудования.");
    }

    public override double CalculateCost()
    {
        return Area * PricePerSquareMeter;
    }

    public override string GetDescription()
    {
        return $"Промышленный объект площадью {Area:N2} м².";
    }
}
