namespace ConstructionCompany;

public abstract class ConstructionObject
{
    public string Name { get; set; }
    public string Address { get; set; }
    public double Cost { get; set; }
    public string ConstructionStage { get; set; }

    protected ConstructionObject(string name, string address, double cost, string constructionStage = "подготовка площадки")
    {
        Name = name;
        Address = address;
        Cost = cost;
        ConstructionStage = constructionStage;
    }

    public void ShowInfo()
    {
        Console.WriteLine($"Название: {Name}");
        Console.WriteLine($"Адрес: {Address}");
        Console.WriteLine($"Стоимость: {Cost:N2} руб.");
        Console.WriteLine($"Этап строительства: {ConstructionStage}");
        Console.WriteLine($"Описание: {GetDescription()}");
    }

    public abstract void Build();
    public abstract double CalculateCost();
    public abstract string GetDescription();
}
