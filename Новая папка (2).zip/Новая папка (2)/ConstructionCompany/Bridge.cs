namespace ConstructionCompany;

public class Bridge : ConstructionObject
{
    public double LengthMeters { get; set; }
    public double CostPerMeter { get; set; }

    public Bridge(string name, string address, double lengthMeters, double costPerMeter, string stage)
        : base(name, address, 0, stage)
    {
        LengthMeters = lengthMeters;
        CostPerMeter = costPerMeter;
        Cost = CalculateCost();
    }

    public override void Build()
    {
        Console.WriteLine($"Строится мост «{Name}»: возведение опор, монтаж пролётных конструкций и дорожного покрытия.");
    }

    public override double CalculateCost()
    {
        return LengthMeters * CostPerMeter;
    }

    public override string GetDescription()
    {
        return $"Мост длиной {LengthMeters:N0} м.";
    }
}
