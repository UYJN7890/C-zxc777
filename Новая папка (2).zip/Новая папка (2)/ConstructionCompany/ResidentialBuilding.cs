namespace ConstructionCompany;

public class ResidentialBuilding : ConstructionObject
{
    public double Area { get; set; }
    public double PricePerSquareMeter { get; set; }

    public ResidentialBuilding(string name, string address, double area, double pricePerSquareMeter, string stage)
        : base(name, address, 0, stage)
    {
        Area = area;
        PricePerSquareMeter = pricePerSquareMeter;
        Cost = CalculateCost();
    }

    public override void Build()
    {
        Console.WriteLine($"Строится жилое здание «{Name}»: возведение стен и отделка квартир.");
    }

    public override double CalculateCost()
    {
        return Area * PricePerSquareMeter;
    }

    public override string GetDescription()
    {
        return $"Жилое здание площадью {Area:N2} м².";
    }
}
