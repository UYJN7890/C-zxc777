namespace ConstructionCompany;

public class Road : ConstructionObject
{
    public double LengthMeters { get; set; }
    public double CostPerMeter { get; set; }

    public Road(string name, string address, double lengthMeters, double costPerMeter, string stage)
        : base(name, address, 0, stage)
    {
        LengthMeters = lengthMeters;
        CostPerMeter = costPerMeter;
        Cost = CalculateCost();
    }

    public override void Build()
    {
        Console.WriteLine($"Строится дорога «{Name}»: подготовка основания, укладка асфальта и нанесение разметки.");
    }

    public override double CalculateCost()
    {
        return LengthMeters * CostPerMeter;
    }

    public override string GetDescription()
    {
        return $"Автомобильная дорога длиной {LengthMeters:N0} м.";
    }
}
