const pages = {
  overview: { title: "Добро пожаловать", crumb: "Обзор" },
  objects: { title: "Строительные объекты", crumb: "Объекты" },
  projects: { title: "Проекты компании", crumb: "Проекты" },
  team: { title: "Команда компании", crumb: "Сотрудники" },
  costs: { title: "Стоимость строительства", crumb: "Стоимость" },
  work: { title: "Ход строительных работ", crumb: "Ход работ" }
};

const typeNames = {
  ResidentialBuilding: "Жилое здание",
  CommercialBuilding: "Коммерческое",
  Road: "Дорога",
  Bridge: "Мост",
  IndustrialBuilding: "Промышленный"
};
const positionNames = { Builder: "Строитель", Engineer: "Инженер", Foreman: "Прораб" };
const money = value => new Intl.NumberFormat("ru-RU", {
  style: "currency", currency: "RUB", maximumFractionDigits: 0
}).format(value);

const objectsRequest = fetch("/api/objects").then(response => response.json());
const projectsRequest = fetch("/api/projects").then(response => response.json());
const employeesRequest = fetch("/api/employees").then(response => response.json());
const costsRequest = fetch("/api/costs").then(response => response.json());
const workRequest = fetch("/api/work").then(response => response.json());

function objectRows(objects) {
  return objects.map(item => `<tr>
    <td>${item.name}</td>
    <td><span class="type-pill">${typeNames[item.type] || item.type}</span></td>
    <td>${item.address}</td>
    <td><span class="stage-pill">${item.constructionStage}</span></td>
    <td>${money(item.cost)}</td>
  </tr>`).join("");
}

function renderProjects(projects) {
  if (!projects.length) return '<div class="empty-state">Проектов пока нет</div>';
  return projects.map(project => `<div class="project-row">
    <div><div class="project-name">${project.projectName}</div>
    <div class="project-meta">${new Date(project.startDate).toLocaleDateString("ru-RU")} — ${new Date(project.endDate).toLocaleDateString("ru-RU")}</div></div>
    <div class="project-manager">${project.projectManager}</div>
  </div>`).join("");
}

function showNotice(message) {
  const notice = document.querySelector("#notice");
  notice.textContent = message;
  notice.hidden = false;
  window.setTimeout(() => { notice.hidden = true; }, 3500);
}

async function showPage(page) {
  const current = pages[page] ? page : "overview";
  const [objects, projects, employees, costs, work] = await Promise.all([
    objectsRequest, projectsRequest, employeesRequest, costsRequest, workRequest
  ]);
  document.querySelectorAll("[data-page]").forEach(button => {
    button.classList.toggle("active", button.dataset.page === current && button.classList.contains("nav-item"));
  });
  document.querySelector("#breadcrumb-current").textContent = pages[current].crumb;
  document.querySelector("#page-title").textContent = pages[current].title;
  document.querySelector("#today").textContent = new Date().toLocaleDateString("ru-RU", {
    day: "numeric", month: "long", year: "numeric"
  });
  document.querySelector("#object-count").textContent = objects.length;
  document.querySelector("#project-count").textContent = projects.length;
  document.querySelector("#employee-count").textContent = employees.length;
  document.querySelector("#total-cost").textContent = money(costs.total);

  const panel = document.querySelector("#main-panel");
  const title = document.querySelector("#panel-title");
  const body = document.querySelector("#main-table");
  const tableHead = body.closest("table").querySelector("thead");
  const secondary = document.querySelector("#secondary-panel");
  secondary.hidden = current !== "overview" && current !== "projects";
  panel.hidden = current === "work";

  if (current === "overview" || current === "objects") {
    title.textContent = current === "overview" ? "Строительные объекты" : "Все строительные объекты";
    tableHead.innerHTML =
      "<tr><th>Название объекта</th><th>Тип</th><th>Адрес</th><th>Этап</th><th>Стоимость</th></tr>";
    body.innerHTML = objectRows(current === "overview" ? objects.slice(0, 4) : objects);
  } else if (current === "projects") {
    title.textContent = "Список проектов";
    tableHead.innerHTML =
      "<tr><th>Название проекта</th><th>Начало</th><th>Окончание</th><th>Менеджер проекта</th></tr>";
    body.innerHTML = projects.map(project => `<tr><td>${project.projectName}</td>
      <td>${new Date(project.startDate).toLocaleDateString("ru-RU")}</td>
      <td>${new Date(project.endDate).toLocaleDateString("ru-RU")}</td>
      <td>${project.projectManager}</td></tr>`).join("");
    secondary.querySelector("h2").textContent = "Все проекты";
    secondary.querySelector("#project-list").innerHTML = renderProjects(projects);
  } else if (current === "team") {
    title.textContent = "Сотрудники компании";
    tableHead.innerHTML =
      "<tr><th>Сотрудник</th><th>Должность</th><th>Возраст</th><th>Зарплата</th></tr>";
    body.innerHTML = employees.map(employee => `<tr><td>${employee.fullName}</td>
      <td><span class="type-pill">${positionNames[employee.position] || employee.position}</span></td>
      <td>${employee.age}</td><td>${money(employee.salary)}</td></tr>`).join("");
  } else if (current === "costs") {
    title.textContent = "Расчёт стоимости по объектам";
    tableHead.innerHTML =
      "<tr><th>Название объекта</th><th>Стоимость строительства</th></tr>";
    body.innerHTML = costs.items.map(item => `<tr><td>${item.name}</td><td>${money(item.cost)}</td></tr>`).join("") +
      `<tr><td><strong>Итого</strong></td><td><strong>${money(costs.total)}</strong></td></tr>`;
  } else if (current === "work") {
    title.textContent = "Выполнение работ";
    panel.hidden = false;
    tableHead.innerHTML =
      "<tr><th>Объект / сотрудник</th><th>Информация</th></tr>";
    body.innerHTML = work.objects.map(item => `<tr><td>${item.name}</td><td>${item.description}</td></tr>`).join("") +
      work.employees.map(employee => `<tr><td>${employee.fullName}</td><td>${positionNames[employee.position] || employee.position} — выполняет работы на объектах</td></tr>`).join("");
  }

  if (current !== "projects") {
    secondary.querySelector("h2").textContent = "Текущие проекты";
    secondary.querySelector("#project-list").innerHTML = renderProjects(projects.slice(0, 2));
  }
  if (current === "work") showNotice("Данные о работах и сотрудниках загружены");
}

document.querySelectorAll("[data-page]").forEach(button => {
  button.addEventListener("click", event => {
    event.preventDefault();
    showPage(button.dataset.page).catch(() => showNotice("Не удалось загрузить данные. Перезапустите приложение."));
  });
});

Promise.all([objectsRequest, projectsRequest, employeesRequest, costsRequest, workRequest])
  .then(() => showPage("overview"))
  .catch(() => showNotice("Сервер недоступен. Перезапустите приложение."));
