namespace ConstructionCompany;

public class ConstructionProject
{
    public string ProjectName { get; set; }
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }
    public string ProjectManager { get; set; }

    public ConstructionProject(string projectName, DateTime startDate, DateTime endDate, string projectManager)
    {
        ProjectName = projectName;
        StartDate = startDate;
        EndDate = endDate;
        ProjectManager = projectManager;
    }

    public void ShowProjectInfo()
    {
        Console.WriteLine($"Проект: {ProjectName}");
        Console.WriteLine($"Начало: {StartDate:d}");
        Console.WriteLine($"Окончание: {EndDate:d}");
        Console.WriteLine($"Проектный менеджер: {ProjectManager}");
    }
}
