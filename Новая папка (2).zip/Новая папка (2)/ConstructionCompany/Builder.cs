namespace ConstructionCompany;

public class Builder : Employee
{
    public Builder(string fullName, int age, double salary) : base(fullName, age, salary) { }

    public override void Work()
    {
        Console.WriteLine($"{FullName} выполняет кладку, заливку бетона и возведение стен.");
    }
}
