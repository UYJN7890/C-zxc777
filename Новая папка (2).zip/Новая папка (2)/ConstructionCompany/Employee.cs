namespace ConstructionCompany;

public abstract class Employee
{
    public string FullName { get; set; }
    public int Age { get; set; }
    public double Salary { get; set; }

    protected Employee(string fullName, int age, double salary)
    {
        FullName = fullName;
        Age = age;
        Salary = salary;
    }

    public void ShowEmployeeInfo()
    {
        Console.WriteLine($"ФИО: {FullName}");
        Console.WriteLine($"Возраст: {Age}");
        Console.WriteLine($"Зарплата: {Salary:N2} руб.");
    }

    public abstract void Work();
}
