namespace ConstructionCompany;

public class Foreman : Employee
{
    public Foreman(string fullName, int age, double salary) : base(fullName, age, salary) { }

    public override void Work()
    {
        Console.WriteLine($"{FullName} контролирует бригаду, распределяет задачи и следит за сроками.");
    }
}
